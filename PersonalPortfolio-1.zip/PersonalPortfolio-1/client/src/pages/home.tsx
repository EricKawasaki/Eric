import { NavMenu } from "@/components/nav-menu";
import { About } from "@/components/sections/about";
import { Interests } from "@/components/sections/interests";
import { Activities } from "@/components/sections/activities";
import { Achievements } from "@/components/sections/achievements";
import { Social } from "@/components/sections/social";

export default function Home() {
  return (
    <div className="bg-background text-foreground">
      <NavMenu />
      <main className="pt-16">
        <About />
        <Interests />
        <Activities />
        <Achievements />
        <Social />
      </main>
    </div>
  );
}

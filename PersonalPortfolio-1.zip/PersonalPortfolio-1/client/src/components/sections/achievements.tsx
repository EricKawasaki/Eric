import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Trophy, GripVertical, Music, Sword, Coins, Waves } from "lucide-react";

const achievements = [
  {
    icon: <GripVertical className="h-6 w-6" />,
    title: "Chess Champion",
    event: "Chess Tournament",
    description: "Achieved first place in chess competition, demonstrating strategic thinking and tactical skills."
  },
  {
    icon: <Trophy className="h-6 w-6" />,
    title: "Film Production",
    event: "Short Films & Productions",
    description: "Successfully produced multiple films and short features, developing directorial and storytelling abilities."
  },
  {
    icon: <Music className="h-6 w-6" />,
    title: "Band Participation",
    event: "Musical Performance",
    description: "Active member of a band, contributing to live performances and musical productions."
  },
  {
    icon: <Sword className="h-6 w-6" />,
    title: "Judo Achievement",
    event: "Judo Competition",
    description: "Secured third place in judo competition, showcasing discipline and athletic prowess."
  },
  {
    icon: <Coins className="h-6 w-6" />,
    title: "Fundraising Success",
    event: "Raffle Sales",
    description: "Generated $2,000 through successful raffle sales, demonstrating entrepreneurial skills."
  },
  {
    icon: <Waves className="h-6 w-6" />,
    title: "Swimming Victory",
    event: "Swimming Competition",
    description: "Won swimming competition, displaying athletic excellence and competitive spirit."
  }
];

export function Achievements() {
  return (
    <section id="achievements" className="min-h-screen pt-24 pb-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold mb-8 text-primary">Achievements</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {achievements.map((achievement, index) => (
              <motion.div
                key={achievement.title}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-primary/10 rounded-lg text-primary">
                        {achievement.icon}
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold mb-1">{achievement.title}</h3>
                        <p className="text-sm text-primary mb-2">{achievement.event}</p>
                        <p className="text-muted-foreground">{achievement.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Clapperboard, GraduationCap, Languages, Music } from "lucide-react";

const interests = [
  {
    icon: <Clapperboard className="h-6 w-6" />,
    title: "Cinema & Film Direction",
    description: "Passionate about filmmaking, screenwriting, and developing unique directorial perspectives in cinema."
  },
  {
    icon: <GraduationCap className="h-6 w-6" />,
    title: "US College Education",
    description: "Pursuing higher education in the United States to develop my skills in film and creative arts."
  },
  {
    icon: <Languages className="h-6 w-6" />,
    title: "Japanese Language",
    description: "Committed to achieving fluency in Japanese to broaden cultural understanding and creative perspectives."
  },
  {
    icon: <Music className="h-6 w-6" />,
    title: "Professional Music",
    description: "Dedicated to developing professional musical skills, whether in band performance or solo artistry."
  }
];

export function Interests() {
  return (
    <section id="interests" className="min-h-screen pt-24 pb-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold mb-8 text-primary">Interests</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {interests.map((interest, index) => (
              <motion.div
                key={interest.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-primary/10 rounded-lg text-primary">
                        {interest.icon}
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold mb-2">{interest.title}</h3>
                        <p className="text-muted-foreground">{interest.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
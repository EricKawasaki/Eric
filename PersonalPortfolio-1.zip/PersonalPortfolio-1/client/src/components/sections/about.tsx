import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";

export function About() {
  return (
    <section id="about" className="min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold mb-8 text-primary">
            Hi, welcome to Eric's Portfolio
          </h2>

          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl text-primary">
                  Personal Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-foreground leading-relaxed">
                  My full name is <span className="font-medium">Eric Yugo Kawasaki</span>, 
                  and I'm 17 years old, currently in 11th grade at Springdale 
                  Preparatory School. I was born in São Paulo, Brazil, and in 2020, 
                  I moved to Santos, where I continued my educational journey.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-2xl text-primary">
                  Educational Background
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-foreground leading-relaxed">
                  My academic path includes studying at prestigious institutions such as 
                  <span className="font-medium"> Escola Americana de Santos</span> and 
                  <span className="font-medium"> Jean Piaget</span>. In 2023, I had the 
                  valuable experience of attending <span className="font-medium">LA Long 
                  Beach College</span> as a boarding student, which broadened my horizons 
                  and exposed me to diverse perspectives.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-2xl text-primary">
                  Career Aspirations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-foreground leading-relaxed">
                  I aspire to become a <span className="font-medium">film director and writer</span>, 
                  with the possibility of exploring acting as well. My passion for creativity 
                  extends to music, where I envision myself either leading a band or pursuing 
                  a solo career.
                </p>
                <p className="text-foreground leading-relaxed mt-4">
                  In the world of cinema, I draw inspiration from legendary directors:
                </p>
                <ul className="list-disc list-inside mt-2 space-y-2 text-foreground">
                  <li><span className="font-medium">Steven Spielberg</span> - for his career path</li>
                  <li><span className="font-medium">Stanley Kubrick</span> - for his production excellence</li>
                  <li><span className="font-medium">Damien Chazelle</span> - for his comprehensive approach to filmmaking</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
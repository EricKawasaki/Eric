import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { GripVertical, Languages, Clapperboard, Dumbbell, Music, BookOpen } from "lucide-react";

const activities = [
  {
    icon: <GripVertical className="h-6 w-6" />,
    title: "Chess",
    period: "Current",
    description: "Developing strategic thinking and decision-making skills through chess."
  },
  {
    icon: <Languages className="h-6 w-6" />,
    title: "Japanese Language",
    period: "Current",
    description: "Actively learning Japanese language and culture."
  },
  {
    icon: <Clapperboard className="h-6 w-6" />,
    title: "Film Analysis",
    period: "Ongoing",
    description: "Watching and critiquing films while studying cinema theory to develop directorial perspective."
  },
  {
    icon: <Dumbbell className="h-6 w-6" />,
    title: "Sports",
    period: "Regular",
    description: "Staying active through badminton and basketball, developing teamwork and physical skills."
  },
  {
    icon: <Music className="h-6 w-6" />,
    title: "Music",
    period: "Current",
    description: "Learning multiple instruments including saxophone, guitar, bass, and developing vocal skills."
  },
  {
    icon: <BookOpen className="h-6 w-6" />,
    title: "Cinema Theory",
    period: "Ongoing",
    description: "Studying film theory and directorial techniques to enhance understanding of cinema."
  }
];

export function Activities() {
  return (
    <section id="activities" className="min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold mb-8 text-primary">Activities</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {activities.map((activity, index) => (
              <motion.div
                key={activity.title}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-primary/10 rounded-lg text-primary">
                        {activity.icon}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="text-xl font-semibold">{activity.title}</h3>
                          <span className="text-sm text-muted-foreground">
                            {activity.period}
                          </span>
                        </div>
                        <p className="text-muted-foreground">{activity.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
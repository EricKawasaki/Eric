import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Instagram, Mail, Phone, Users } from "lucide-react";

const familyConnections = [
  {
    name: "Cristina Mayumi Sanada",
    relation: "Mother",
    description: "Professional chef with expertise in cooking",
  },
  {
    name: "Cláudio Kazuyoshi Kawasaki",
    relation: "Father",
    description: "Bank legal processor and entrepreneur",
  },
  {
    name: "Larissa Aya Kawasaki",
    relation: "Sister",
    description: "11 years old",
  },
  {
    name: "Kauanny Cristina Rosa Soares",
    relation: "Girlfriend",
    description: "2nd year college student, 18 years old",
  },
];

const contactInfo = [
  {
    icon: <Instagram className="h-5 w-5" />,
    label: "Instagram",
    href: "https://instagram.com/japonegro_do_drip",
    username: "@japonegro_do_drip"
  },
  {
    icon: <Phone className="h-5 w-5" />,
    label: "Phone",
    href: "tel:+5511998000210",
    username: "+55 (11) 99800-0210"
  },
  {
    icon: <Mail className="h-5 w-5" />,
    label: "Primary Email",
    href: "mailto:eric.y.kawasaki@gmail.com",
    username: "eric.y.kawasaki@gmail.com"
  },
  {
    icon: <Mail className="h-5 w-5" />,
    label: "Secondary Email",
    href: "mailto:yugokawasaki@yahoo.com.br",
    username: "yugokawasaki@yahoo.com.br"
  }
];

export function Social() {
  return (
    <section id="social" className="min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold mb-8 text-primary">Family & Connections</h2>
          <Card className="mb-8">
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {familyConnections.map((person, index) => (
                  <motion.div
                    key={person.name}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="flex items-start gap-4"
                  >
                    <div className="p-2 bg-primary/10 rounded-lg text-primary">
                      <Users className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-semibold">{person.name}</h3>
                      <p className="text-sm text-primary mb-1">{person.relation}</p>
                      <p className="text-sm text-muted-foreground">
                        {person.description}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>

          <h2 className="text-3xl font-bold mb-8 text-primary">Contact Information</h2>
          <Card>
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {contactInfo.map((contact, index) => (
                  <motion.div
                    key={contact.label}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <Button
                      variant="outline"
                      className="w-full justify-start gap-4 h-auto py-4"
                      asChild
                    >
                      <a
                        href={contact.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="no-underline"
                      >
                        <div className="p-2 bg-primary/10 rounded-lg text-primary">
                          {contact.icon}
                        </div>
                        <div className="flex flex-col items-start">
                          <span className="font-semibold">{contact.label}</span>
                          <span className="text-sm text-muted-foreground">
                            {contact.username}
                          </span>
                        </div>
                      </a>
                    </Button>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}